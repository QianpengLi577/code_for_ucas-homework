python runme.py

os:win 11
python 3.8
numpy 1.20.2
scipy 1.7.1