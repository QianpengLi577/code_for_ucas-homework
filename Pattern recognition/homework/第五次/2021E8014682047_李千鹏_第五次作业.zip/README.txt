cd code_data
python PR_5.py

** 运行程序会在控制台输出分类信息，并得到vehrecord.csv 和 orlrecord.csv两个文件(记录分类类型)

** vehicle_x.mat 与 vehicle_y.mat为vehicle的数据和标签(通过提供的matlab代码提取数据另存得到)