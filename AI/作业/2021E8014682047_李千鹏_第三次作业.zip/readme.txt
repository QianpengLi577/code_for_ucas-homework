终端输入:
python AI_3.py

环境:
python 3.8
numpy 1.20.1